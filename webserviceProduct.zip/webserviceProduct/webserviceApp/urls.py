from django.urls import path

from webserviceApp import views

urlpatterns = [
    # For the Provider CRUD Operator -
    path('create_service/', views.create_service),
    path('get_service/<str:_id>', views.get_service),
    path('update_service/<str:_id>', views.update_service),
    path('delete_service/<str:_id>', views.delete_service),
    path('list_services/', views.list_services),

    # For the LogIn, LogOut and Register -
    path('register/', views.register),
    path('login/', views.login),
    path('logout/', views.logout),



]   