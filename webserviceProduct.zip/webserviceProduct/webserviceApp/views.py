
from rest_framework.response import Response
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework import status
from webserviceApp.models import ProviderService
from webserviceApp.serializers import ProviderServiceSerializer, UserSerializer
from bson import ObjectId
from rest_framework.permissions import IsAuthenticated
from rest_framework.permissions import AllowAny
from django.contrib.auth.hashers import check_password
from .models import User




@api_view(['POST'])
@permission_classes([AllowAny])
def create_service(request):
    serializer = ProviderServiceSerializer(data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([AllowAny])
def get_service(request, _id):
    try:
        service = ProviderService.objects.get(_id=(ObjectId(_id)))
    except ProviderService.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    serializer = ProviderServiceSerializer(service)
    return Response(serializer.data)

@api_view(['PUT'])
@permission_classes([AllowAny])
def update_service(request, _id):
    try:
        service = ProviderService.objects.get(_id=(ObjectId(_id)))
    except ProviderService.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    serializer = ProviderServiceSerializer(service, data=request.data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['DELETE'])
@permission_classes([AllowAny])
def delete_service(request, _id):
    try:
        service = ProviderService.objects.get(_id=(ObjectId(_id)))
    except ProviderService.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)

    service.delete()
    return Response({'message':"Deleted Data Succesafull"},status=status.HTTP_204_NO_CONTENT)

@api_view(['POST'])
@permission_classes([AllowAny])
def list_services(request):
    services = ProviderService.objects.all()
    serializer = ProviderServiceSerializer(services, many=True)
    return Response(serializer.data)



# -----------------------------------------------------------------------------

# Register a user
@api_view(['POST'])
@permission_classes([AllowAny])
def register(request):
    serializer = UserSerializer(data=request.data)
    if serializer.is_valid(): 
        serializer.save()
        return Response({'message': "User registered successfully"}, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Login a user (session-based)

@api_view(['POST'])
@permission_classes([AllowAny])
def login(request):
    username = request.data.get('username')
    password = request.data.get('password')
    selected_role = request.data.get('role')

    try:
        # Find the user by username
        user = User.objects.get(username=username)
        
        if check_password(password, user.password):
            # Check if the selected role matches the user's actual role
            if selected_role == user.role:
                
                if user.role == 'admin':
                    panel = 'Admin Dashboard'
                elif user.role == 'provider':
                    panel = 'Provider Dashboard'
                elif user.role == 'client':
                    panel = 'Client Dashboard'
                else:
                    return Response({'error': 'Invalid role'}, status=status.HTTP_403_FORBIDDEN)
                
                return Response({
                    'message': 'Login successful',
                    'role': user.role,
                    'redirect_to': panel
                }, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Selected role does not match'}, status=status.HTTP_401_UNAUTHORIZED)
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)
        
    except User.DoesNotExist:
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)



# For logOut -
@api_view(['POST'])
@permission_classes([AllowAny])
def logout(request):
    try:
        request.auth.delete()
        return Response({'message': 'Logout successful'}, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({'error': 'Something went wrong during logout'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


